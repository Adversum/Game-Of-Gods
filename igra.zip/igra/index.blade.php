<!doctype html>
<html>
    <head>
        <meta charset="UTF-8" />
        <title>Satan</title>
        <script src="phaser.js"></script>
    </head>
    <body>

    <script type="text/javascript">	 
	
	window.onload = function() {
	
	var game = new Phaser.Game(800, 600, Phaser.AUTO, '', {preload: preload, create: create, update: update, render: render});

	var player;                  // игрок
	var hp;                      // жизни
	var field;                   // бекграунд
	var direction;               // направление
	var effect;                  // эффект сзади игрока
	var bullets;                 // пули
	var evilBullets;              // пули врагов
    var fireButton;              // нажатие кнопки выстрела (пробел или ЛКМ)
	var bulletTimer = 1;         
	var bulletSpeed = 500;       // скорость выстрела
	var BulletSpacing = 100;     // перезарядка (чем меньше, тем быстрее)
	var Enemy1;                  // виды врагов
	var Enemy2;
	var Enemy3;
	var explosions;              // столкновение
	var Enemy1LaunchTimer;       // запуск титухов
	var Enemy2LaunchTimer;
	var Enemy3LaunchTimer;
	var score = 0;               // очки и вывод
	var scoreText;

	function preload() {
		game.load.image('field', './pics/galaxi.png');      // загрузка картинок, спрайтов
		game.load.image('ship', './pics/raketa.png');
		game.load.image('bullet', './pics/bullet.png');
		game.load.image('evilBullet', './pics/bullet.png');
		game.load.image('troll1', './pics/aster.png'); 
		game.load.image('troll2', './pics/ship.png');
		game.load.spritesheet('explosion', './pics/explode.png', 128, 128);
		game.load.audio('hell', './musc/HellVerse1.mp3');
		game.load.audio('gameover', './musc/gameover.mp3');
		game.load.audio('wpn1', './musc/wpn1.mp3');
	}

	function create() {
		music = game.add.audio('hell');
		gameover = game.add.audio('gameover');
		wpn1 = game.add.audio('wpn1');
	//	music.play();
		wpn1.allowMultiple = true;
		field = game.add.tileSprite(0, 0, 800, 600, 'field');  // установка фона
		bullets = game.add.group();                       // описание пули
		bullets.enableBody = true;   
		bullets.physicsBodyType = Phaser.Physics.ARCADE;
		bullets.createMultiple(30, 'bullet');
		bullets.setAll('anchor.x', 0.5);
		bullets.setAll('anchor.y', 1);
		bullets.setAll('outOfBoundsKill', true);
		bullets.setAll('checkWorldBounds', true);
		
		player = game.add.sprite(400, 600, 'ship');       // установка игрока
		player.anchor.setTo(0.5, 0.5);
		player.health = 1000;                              // количество HP и обработка столкновения
		player.weaponLevel = 3;
		
		hp = game.add.text(game.world.width - 150, 550, 'HP: ' + player.health +'%', { font: '20px Arial', fill: '#999999' });
        hp.render = function () {
			hp.text = 'HP: ' + Math.max(player.health, 0) +'%';   // отображение HP
		}  
		
		scoreText = game.add.text(game.world.width - 150, 570, '', { font: '20px Arial', fill: '#999999' });
		scoreText.render = function () {
			scoreText.text = 'Score: ' + score;                   // отображение очков
		};
		scoreText.render();
		
		game.physics.enable(player, Phaser.Physics.ARCADE);  
		
		Enemy1 = game.add.group();                          // описание первого врага
		Enemy1.enableBody = true;
		Enemy1.physicsBodyType = Phaser.Physics.ARCADE;
		Enemy1.createMultiple(5, 'troll1');
		Enemy1.setAll('anchor.x', 0.5);
		Enemy1.setAll('anchor.y', 0.5);
		Enemy1.setAll('scale.x', 0.5);
		Enemy1.setAll('scale.y', 0.5);
		Enemy1.setAll('angle', 180);
		Enemy1.setAll('outOfBoundsKill', true);
		Enemy1.setAll('checkWorldBounds', true);
		Enemy1.forEach(function(enemy){
			enemy.damageAmount = 10; 
			enemy.body.setSize(enemy.width * 3 / 4, enemy.height * 3 / 4);  // более точное столкновение
		});
		
		game.time.events.add(1000, launchEnemy1);                        // старт метеоритов
		
		Enemy2 = game.add.group();                        // описание второго врага
		Enemy2.enableBody = true;
		Enemy2.physicsBodyType = Phaser.Physics.ARCADE;
		Enemy2.createMultiple(30, 'troll2');
		Enemy2.setAll('anchor.x', 0.5);
		Enemy2.setAll('anchor.y', 0.5);
		Enemy2.setAll('scale.x', 0.5);
		Enemy2.setAll('scale.y', 0.5);
		Enemy2.setAll('angle', 180);
		Enemy2.forEach(function(enemy){
			enemy.damageAmount = 40;
			enemy.body.setSize(enemy.width * 3 / 4, enemy.height * 3 / 4);  // более точное столкновение
		});
		
		game.time.events.add(100, launchEnemy2);
		
		Enemy2evilBullets = game.add.group();                             // описание пуль второго врага
		Enemy2evilBullets.enableBody = true;
		Enemy2evilBullets.physicsBodyType = Phaser.Physics.ARCADE;
		Enemy2evilBullets.createMultiple(30, 'evilBullet');
		Enemy2evilBullets.callAll('crop', null, {x: 90, y: 0, width: 90, height: 70});
		Enemy2evilBullets.setAll('alpha', 0.9);
		Enemy2evilBullets.setAll('anchor.x', 0.5);
		Enemy2evilBullets.setAll('anchor.y', 0.5);
		Enemy2evilBullets.setAll('outOfBoundsKill', true);
		Enemy2evilBullets.setAll('checkWorldBounds', true);
		Enemy2evilBullets.forEach(function(enemy){
			enemy.body.setSize(20, 20);
		});
		
        direction = game.input.keyboard.createCursorKeys();       // управление с помощью стрелок
		fireButton = game.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR); // огонь с помощью пробела
		effect = game.add.emitter(player.x, player.y + 10, 400);  // эффект сзади коробля
    	effect.width = 10;
    	effect.makeParticles('bullet');
    	effect.setXSpeed(30, -30);
		effect.setYSpeed(200, 180);
		effect.setRotation(50,-50);
		effect.setAlpha(1, 0.01, 800);
		effect.setScale(0.05, 0.4, 0.05, 0.4, 2000, Phaser.Easing.Quintic.Out);
		effect.start(false, 5000, 10);
		
    	explosions = game.add.group();                       // обработка события столкновения
		explosions.enableBody = true;
		explosions.physicsBodyType = Phaser.Physics.ARCADE;
		explosions.createMultiple(30, 'explosion');
		explosions.setAll('anchor.x', 0.5);
		explosions.setAll('anchor.y', 0.5);
		explosions.forEach( function(explosion) {
			explosion.animations.add('explosion');
		}); 
	}
	
	function update() {
		if (player.alive) {
			field.tilePosition.y += 0.1;    // "передвижение" фона при жизни игркока
		}			// "передвижение" фона
	    player.body.velocity.setTo(0, 0);	
		if (direction.left.isDown)	      // управление короблем
		{ 
			player.body.velocity.x = -100;
		}  
		if (direction.right.isDown)
		{
			player.body.velocity.x = 100;
		} 	
		if (direction.up.isDown)
		{
			player.body.velocity.y = -100;
		} 
		if (direction.down.isDown)
		{
			player.body.velocity.y = 100;
		} 
		if (player.x > game.width - 25) {  // запрет на выход за границы экрана
			player.x = game.width - 25;
			player.body.acceleration.x = 0;
		}
		if (player.x < 25) {
			player.x = 25;
			player.body.acceleration.x = 0;
		}
		if (player.y > game.height - 25) {  
			player.y = game.height - 25;
			player.body.acceleration.y = 0;
		}
		if (player.y < 25) {
			player.y = 25;
			player.body.acceleration.y = 0;
		}
		if (player.alive && (fireButton.isDown || game.input.activePointer.isDown)) {  // при нажатии пробела
			fireBullet();
    	}
		effect.x = player.x;   // передвижение эффекта сзади коробля
		effect.y = player.y;
	 	game.physics.arcade.overlap(player, Enemy1, shipCollide, null, this);  // столкновение
		game.physics.arcade.overlap(Enemy1, bullets, hitEnemy, null, this);   // попадание во врага
		game.physics.arcade.overlap(player, Enemy2, shipCollide, null, this);
		game.physics.arcade.overlap(bullets, Enemy2, hitEnemy, null, this);	
		game.physics.arcade.overlap(Enemy2evilBullets, player, enemyHitsPlayer, null, this);
		if (! player.alive){            // когда игрок умирает
			game.time.events.remove(Enemy1LaunchTimer);
			game.time.events.remove(Enemy2LaunchTimer);
			field.tilePosition.y += 0; 
			effect.kill();
			gameOverText = game.add.text(game.world.centerX, game.world.centerY, 'GAME OVER!', { font: '84px Arial', fill: '#fff' });
			gameOverText.anchor.setTo(0.5, 0.5);
			if ( music.volume > 0.1) {
				music.volume -= 0.1;
			}		
		}
	}
	
	function fireBullet() {                                  // событие "Выстрел"
		switch (player.weaponLevel) {
        	case 1:
        	if (game.time.now > bulletTimer){
				var bullet = bullets.getFirstExists(false);
				if (bullet){
					bullet.reset(player.x, player.y);
					bullet.angle = player.angle;
					game.physics.arcade.velocityFromAngle(bullet.angle - 90, bulletSpeed, bullet.body.velocity); 
					bulletTimer = game.time.now + BulletSpacing;
// ЗВУК ВЫСТРЕЛА	wpn1.play(); 
				}
			}
			break;
			
			case 2:
			if (game.time.now > bulletTimer){
				var bullet = bullets.getFirstExists(false);
				if (bullet){
					bullet.reset(player.x, player.y);
					bullet.angle = player.angle;
					game.physics.arcade.velocityFromAngle(bullet.angle - 90, bulletSpeed, bullet.body.velocity); 
		      		bullet.body.velocity.x += player.body.velocity.x;  // движение аля Isaac
					bulletTimer = game.time.now + BulletSpacing;
				}
			}
			break;
			
			case 3:
			if (game.time.now > bulletTimer){
				var bullet = bullets.getFirstExists(false);
				if (bullet){
					bullet.reset(player.x, player.y);
					bullet.angle = player.angle;
					game.physics.arcade.velocityFromAngle(bullet.angle - 90, bulletSpeed, bullet.body.velocity); 
					bullet.body.velocity.x += player.body.velocity.x;  // движение аля Isaac
					bulletTimer = game.time.now + BulletSpacing;
				}
			}
		}
	}
	
	function launchEnemy1() {                             // запуск врага
		var minEnemy1 = 35;       // 35      
		var maxEnemy1 = 300;       // 300
		var speedEnemy1 = 100;
		var enemy = Enemy1.getFirstExists(false);
		if (enemy) {
			enemy.reset(game.rnd.integerInRange(0, game.width), -20);
			enemy.body.velocity.x = game.rnd.integerInRange(-500, 500);
			enemy.body.velocity.y = speedEnemy1;
			enemy.body.drag.x = 100;  
		}
		Enemy1LaunchTimer = game.time.events.add(game.rnd.integerInRange(minEnemy1, maxEnemy1), launchEnemy1);
	}
	
	function launchEnemy2() {
		var startingX = game.rnd.integerInRange(100, game.width - 100);
		var verticalSpeed = 180;
		var spread = 60;
		var frequency = 70;
		var verticalSpacing = 70;
		var numEnemiesInWave = 5;
		var timeBetweenWaves = 7000;  // 7000
		for (var i = 0; i < numEnemiesInWave; i++) {
			var enemy = Enemy2.getFirstExists(false);
			if (enemy) {                   
				enemy.startingX = player.x; 
				enemy.reset(game.width / 2, -verticalSpacing * i);
				enemy.body.velocity.y = verticalSpeed;
				var bulletSpeed = 500;                   // характеристики пуль второго врага
            	var firingDelay = 2000;
            	enemy.bullets = 10;
            	enemy.lastShot = 0;
				enemy.update = function(){
					this.body.x = this.startingX + Math.sin((this.y) / frequency) * spread; //  Передвижение
					if (this.y > game.height + 200) {  // убийство за экраном
						this.kill();
					}
					enemyBullet = Enemy2evilBullets.getFirstExists(false);         // описание полета вражеской пули
					if (enemyBullet && this.alive && this.bullets 
					&& this.y > game.width / 8 && game.time.now > firingDelay + this.lastShot) {
						this.lastShot = game.time.now;
						this.bullets--;
						enemyBullet.reset(this.x, this.y + this.height / 2);
						enemyBullet.damageAmount = this.damageAmount;
						var angle = game.physics.arcade.moveToObject(enemyBullet, player, bulletSpeed);
						enemyBullet.angle = game.math.radToDeg(angle); 
					} 
				}
			}
		}
		Enemy2LaunchTimer = game.time.events.add(timeBetweenWaves, launchEnemy2);     // новая волна
	}
	
 	function shipCollide(player, enemy) {                 // событие "Столкновение"
		var explosion = explosions.getFirstExists(false);
		explosion.reset(enemy.body.x + enemy.body.halfWidth, enemy.body.y + enemy.body.halfHeight);
		explosion.body.velocity.y = enemy.body.velocity.y;
		explosion.alpha = 0.7;
		explosion.play('explosion', 30, false, true);	
		player.damage(enemy.damageAmount);
		hp.render();
		enemy.kill(); 	
		if (! player.alive){  
			gameover.play();
		}
	}
	
	function hitEnemy(enemy, bullet) {                              // попадание по врагу
		var explosion = explosions.getFirstExists(false);
		explosion.reset(bullet.body.x + bullet.body.halfWidth, bullet.body.y + bullet.body.halfHeight);
		explosion.body.velocity.y = enemy.body.velocity.y;
		explosion.alpha = 0.7;
		explosion.play('explosion', 30, false, true);
		enemy.kill();
		bullet.kill(); 
		score += enemy.damageAmount * 1.5;
		scoreText.render();
	}
	
	function enemyHitsPlayer (player, bullet) {              // попадание по игроку вражеской пули
		var explosion = explosions.getFirstExists(false);
		explosion.reset(player.body.x + player.body.halfWidth, player.body.y + player.body.halfHeight);
		explosion.alpha = 0.7;
		explosion.play('explosion', 30, false, true);
		bullet.kill();
		player.damage(bullet.damageAmount);
		hp.render()
	}   
	
	function render() {
	//	for (var i = 0; i < troll1.length; i++)
    // {
    //     game.debug.body(troll1.children[i]);
    // }
    // game.debug.body(player);
	}
	}
    </script>

    </body>
</html>