<!doctype html>
<html>
    <head>
        <meta charset="UTF-8" />
        <title>Shootem' Up!</title>
        <script defer src="phaser.js"></script>
		<script defer src="http://localhost/laravel/shop/public/jquery.js"> </script>
    </head>
    <body>

    <script type="text/javascript">	 
	
	window.onload = function() {var game;
	$.getJSON("http://localhost/laravel/shop/public/weapons/5", function (data) {
		console.log(data);
		PremiumWeapon = data; 
	    
	 game = new Phaser.Game(800, 600, Phaser.AUTO, '', {preload: preload, create: create, update: update, render: render});
    });
	var player;                  // игрок
	var hp; 				// жизни
	var power = 1;               // сила пули
	var PowerChar = 0;           // сила персонажа
	var SpeedChar = 200;           // скорость
	var BulletSpeedChar = 0;
	var BulletSpacingChar = 0;   // перезарядка (чем больше, тем быстрее)
	var bulletTimer = 1;         
	var DifficultySpeed = 0;
	var BonusType = 0;
	var field;                   // бекграунд             
	var direction;               // направление
	var effect;                  // эффект сзади игрока
	var bullets;                 // пули
	var evilBullets;             // пули врагов
    var fireButton;              // нажатие кнопки выстрела (пробел или ЛКМ)
	var Coop;
	var XBonus;
	var YBonus;
	var Enemy1;                  
	var Enemy2;
	var Enemy3;
	var Enemy4;
	var Lasers;
	var BonusSpacing;            // увеличение скорострельности
	var Enemy1LaunchTimer;       
	var Enemy2LaunchTimer;
	var Enemy3LaunchTimer;
	var Enemy4LaunchTimer;
	var explosions;              // столкновение
	var score = 0;               // очки и вывод
	var scoreText;
	var Evil = 0;
	var EvilCount;				 // счетчик врагов
	var OP = 0;
	var OPText;
	var PremiumWeapon;

	function preload() {
		
		game.load.image('field', './pics/galaxi.png'); 
		game.load.image('ship', './pics/raketa1.png');
		game.load.image('bullet', './pics/bullet1.png');
		game.load.image('evilBullet', './pics/bullet2.png');
		game.load.image('button', './pics/button.png');
		game.load.image('effect', './pics/effect.png');
		game.load.image('troll1', './pics/aster.png'); 
		game.load.image('troll2', './pics/ship.png');
		game.load.image('troll3', './pics/kamikadze.png');
		game.load.image('troll4', './pics/raketa1.png');
		game.load.image('laser', './pics/laser.png');
		game.load.image('brims', './pics/brimst.png');
		game.load.image('speed', './pics/speed.png');
		game.load.image('bulletspeed', './pics/bulletspeed.png');
		game.load.image('bulletspacing', './pics/bulletspacing.png');
		game.load.image('bulletpower', './pics/player1.png');
		game.load.image('OP', './pics/player1.png');
		game.load.image('heart', './pics/heart.png');
		game.load.spritesheet('explosion', './pics/explode.png', 128, 128);
		game.load.audio('gameover', './musc/gameover.mp3');
		game.load.audio('wpn1', './musc/wpn1.mp3');
			
        	
		
	}

	function create() {
		
		gameover = game.add.audio('gameover');
		wpn1 = game.add.audio('wpn1');
		wpn1.allowMultiple = true;
		field = game.add.tileSprite(0, 0, 800, 600, 'field');  
		
		bullets = game.add.group();                       
		bullets.enableBody = true;   
		bullets.physicsBodyType = Phaser.Physics.ARCADE;
		bullets.createMultiple(30, 'bullet');
		bullets.setAll('anchor.x', 2);
		bullets.setAll('anchor.y', 2);
		bullets.setAll('outOfBoundsKill', true);
		bullets.setAll('checkWorldBounds', true);
		
		brimstone = game.add.group();                       
		brimstone.enableBody = true;   
		brimstone.physicsBodyType = Phaser.Physics.ARCADE;
		brimstone.createMultiple(30, 'brims');
		brimstone.setAll('anchor.x', 1);
		brimstone.setAll('anchor.y', 1);
		brimstone.setAll('outOfBoundsKill', true);
		brimstone.setAll('checkWorldBounds', true);
			
		player = game.add.sprite(400, 600, 'ship');       // установка игрока
		player.anchor.setTo(0.5, 0.5);
		player.health = 2000;                              // количество HP и обработка столкновения
		player.weaponLevel = 5;
	
		hp = game.add.text(5, 535, 'HP: ' + player.health +'%', { font: '20px Arial', fill: '#999999' });
        hp.render = function () {
			hp.text = 'HP: ' + Math.max(player.health, 0) +'%';   // отображение HP
		}  
		hp.render();
		
		scoreText = game.add.text(5, 555, '', { font: '20px Arial', fill: '#999999' });
		scoreText.render = function () {
			scoreText.text = 'Score: ' + score;                   // отображение очков 
		};
		scoreText.render();
		
		enemyCount = game.add.text(5, 575, '', { font: '20px Arial', fill: '#999999' });
		enemyCount.render = function () {
			enemyCount.text = 'Memes: ' + Evil;                   // отображение очков
		};
		enemyCount.render();
		
		OPText = game.add.text(760, 575, '', { font: '20px Arial', fill: '#999999' });
		OPText.render = function () {
			OPText.text =  'x' + OP;                   // отображение очков
		};
		OPText.render();
		
		game.physics.enable(player, Phaser.Physics.ARCADE);  	
		
		Bonus1 = game.add.group();                          
		Bonus1.enableBody = true;
		Bonus1.physicsBodyType = Phaser.Physics.ARCADE;
		Bonus1.createMultiple(5, 'speed');
		Bonus1.setAll('anchor.x', 0.5);
		Bonus1.setAll('anchor.y', 0.5);
		Bonus1.setAll('scale.x', 0.5);
		Bonus1.setAll('scale.y', 0.5);
		Bonus1.setAll('outOfBoundsKill', true);
		Bonus1.setAll('checkWorldBounds', true);
		Bonus1.forEach(function(enemy){
			enemy.body.setSize(enemy.width * 3 / 4, enemy.height * 3 / 4);  
		});
		
		Bonus2 = game.add.group();                          
		Bonus2.enableBody = true;
		Bonus2.physicsBodyType = Phaser.Physics.ARCADE;
		Bonus2.createMultiple(5, 'bulletspeed');
		Bonus2.setAll('anchor.x', 0.5);
		Bonus2.setAll('anchor.y', 0.5);
		Bonus2.setAll('scale.x', 0.5);
		Bonus2.setAll('scale.y', 0.5);
		Bonus2.setAll('outOfBoundsKill', true);
		Bonus2.setAll('checkWorldBounds', true);
		Bonus2.forEach(function(enemy){
			enemy.body.setSize(enemy.width * 3 / 4, enemy.height * 3 / 4);  
		});
		
		Bonus3 = game.add.group();                          
		Bonus3.enableBody = true;
		Bonus3.physicsBodyType = Phaser.Physics.ARCADE;
		Bonus3.createMultiple(5, 'bulletspacing');
		Bonus3.setAll('anchor.x', 0.5);
		Bonus3.setAll('anchor.y', 0.5);
		Bonus3.setAll('scale.x', 0.5);
		Bonus3.setAll('scale.y', 0.5);
		Bonus3.setAll('outOfBoundsKill', true);
		Bonus3.setAll('checkWorldBounds', true);
		Bonus3.forEach(function(enemy){
			enemy.body.setSize(enemy.width * 3 / 4, enemy.height * 3 / 4);  
		});
		
		Bonus4 = game.add.group();                          
		Bonus4.enableBody = true;
		Bonus4.physicsBodyType = Phaser.Physics.ARCADE;
		Bonus4.createMultiple(5, 'bulletpower');
		Bonus4.setAll('anchor.x', 0.5);
		Bonus4.setAll('anchor.y', 0.5);
		Bonus4.setAll('scale.x', 0.5);
		Bonus4.setAll('scale.y', 0.5);
		Bonus4.setAll('outOfBoundsKill', true);
		Bonus4.setAll('checkWorldBounds', true);
		Bonus4.forEach(function(enemy){
			enemy.body.setSize(enemy.width * 3 / 4, enemy.height * 3 / 4);  
		});
		
		Bonus5 = game.add.group();                          
		Bonus5.enableBody = true;
		Bonus5.physicsBodyType = Phaser.Physics.ARCADE;
		Bonus5.createMultiple(5, 'OP');
		Bonus5.setAll('anchor.x', 0.5);
		Bonus5.setAll('anchor.y', 0.5);
		Bonus5.setAll('scale.x', 0.5);
		Bonus5.setAll('scale.y', 0.5);
		Bonus5.setAll('outOfBoundsKill', true);
		Bonus5.setAll('checkWorldBounds', true);
		Bonus5.forEach(function(enemy){
			enemy.body.setSize(enemy.width * 3 / 4, enemy.height * 3 / 4);  
		});
		
		Bonus6 = game.add.group();                          
		Bonus6.enableBody = true;
		Bonus6.physicsBodyType = Phaser.Physics.ARCADE;
		Bonus6.createMultiple(5, 'heart');
		Bonus6.setAll('anchor.x', 0.5);
		Bonus6.setAll('anchor.y', 0.5);
		Bonus6.setAll('scale.x', 0.5);
		Bonus6.setAll('scale.y', 0.5);
		Bonus6.setAll('outOfBoundsKill', true);
		Bonus6.setAll('checkWorldBounds', true);
		Bonus6.forEach(function(enemy){
			enemy.body.setSize(enemy.width * 3 / 4, enemy.height * 3 / 4);  
		});
		
		Enemy1 = game.add.group();                          
		Enemy1.enableBody = true;
		Enemy1.physicsBodyType = Phaser.Physics.ARCADE;
		Enemy1.createMultiple(5, 'troll1');
		Enemy1.setAll('anchor.x', 0.5);
		Enemy1.setAll('anchor.y', 0.5);
		Enemy1.setAll('scale.x', 0.5);
		Enemy1.setAll('scale.y', 0.5);
		Enemy1.setAll('outOfBoundsKill', true);
		Enemy1.setAll('checkWorldBounds', true);
		Enemy1.forEach(function(enemy){
			enemy.body.setSize(enemy.width * 2 / 4, enemy.height * 2 / 4);  
		});
		
		Enemy2 = game.add.group();                       
		Enemy2.enableBody = true;
		Enemy2.physicsBodyType = Phaser.Physics.ARCADE;
		Enemy2.createMultiple(30, 'troll2');
		Enemy2.setAll('anchor.x', 0.5);
		Enemy2.setAll('anchor.y', 0.5);
		Enemy2.setAll('scale.x', 0.5);
		Enemy2.setAll('scale.y', 0.5);
		Enemy2.forEach(function(enemy){
			enemy.body.setSize(enemy.width * 3 / 4, enemy.height * 3 / 4); 
		});
			
		Enemy2evilBullets = game.add.group();                            
		Enemy2evilBullets.enableBody = true;
		Enemy2evilBullets.physicsBodyType = Phaser.Physics.ARCADE;
		Enemy2evilBullets.createMultiple(30, 'evilBullet');
		Enemy2evilBullets.callAll('crop', null, {x: 90, y: 0, width: 90, height: 70});
		Enemy2evilBullets.setAll('alpha', 0.9);
		Enemy2evilBullets.setAll('anchor.x', 0.5);
		Enemy2evilBullets.setAll('anchor.y', 0.5);
		Enemy2evilBullets.setAll('outOfBoundsKill', true);
		Enemy2evilBullets.setAll('checkWorldBounds', true);
		Enemy2evilBullets.forEach(function(enemy){
			enemy.body.setSize(20, 20);
		});
		
		Enemy3 = game.add.group();                        
		Enemy3.enableBody = true;
		Enemy3.physicsBodyType = Phaser.Physics.ARCADE;
		Enemy3.createMultiple(30, 'troll3');
		Enemy3.setAll('anchor.x', 0.5);
		Enemy3.setAll('anchor.y', 0.5);
		Enemy3.setAll('scale.x', 0.5);
		Enemy3.setAll('scale.y', 0.5);
		Enemy3.forEach(function(enemy){
			enemy.body.setSize(enemy.width * 3 / 4, enemy.height * 3 / 4);  
		});
		
		Enemy4 = game.add.group();                       
		Enemy4.enableBody = true;
		Enemy4.physicsBodyType = Phaser.Physics.ARCADE;
		Enemy4.createMultiple(30, 'troll4');
		Enemy4.setAll('anchor.x', 0.5);
		Enemy4.setAll('anchor.y', 0.5);
		Enemy4.setAll('scale.x', 0.5);
		Enemy4.setAll('scale.y', 0.5);
		Enemy4.setAll('angle', 180);
		Enemy4.forEach(function(enemy){
			enemy.body.setSize(enemy.width * 3 / 4, enemy.height * 2 / 4);  
		});
		
		Enemy5 = game.add.group();                       
		Enemy5.enableBody = true;
		Enemy5.physicsBodyType = Phaser.Physics.ARCADE;
		Enemy5.createMultiple(30, 'troll4');
		Enemy5.setAll('anchor.x', 0.5);
		Enemy5.setAll('anchor.y', 0.5);
		Enemy5.setAll('scale.x', 0.5);
		Enemy5.setAll('scale.y', 0.5);
		Enemy5.setAll('angle', 180);
		Enemy5.forEach(function(enemy){
			enemy.body.setSize(enemy.width * 3 / 4, enemy.height * 2 / 4);  
		});
		
		effect = game.add.emitter(player.x, player.y, 400);  // эффект сзади коробля
    	effect.width = 10;
    	effect.makeParticles('effect');
    	effect.setXSpeed(30, -30);
		effect.setYSpeed(200, 180);
		effect.setRotation(50, -50);  
		effect.setAlpha(1, 0.01, 800);  
		effect.setScale(0.05, 0.4, 0.05, 0.4, 2000, Phaser.Easing.Quintic.Out);  
		effect.start(false, 5000, 10);
		
    	explosions = game.add.group();                       // обработка события столкновения
		explosions.enableBody = true;
		explosions.physicsBodyType = Phaser.Physics.ARCADE;
		explosions.createMultiple(30, 'explosion');
		explosions.setAll('anchor.x', 0.5);
		explosions.setAll('anchor.y', 0.5);
		explosions.forEach(function(explosion){
			explosion.animations.add('explosion');
		});  
		
		lasers = game.add.group();                       // обработка события столкновения
		lasers.enableBody = true;
		lasers.physicsBodyType = Phaser.Physics.ARCADE;
		lasers.createMultiple(30, 'laser');
		lasers.setAll('anchor.x', 0.5);
		lasers.setAll('anchor.y', 0.5);
		lasers.forEach(function(laser){
			laser.animations.add('laser');
		});  
		
		game.time.events.add(500, launchEnemy1);
		game.time.events.add(1500, launchEnemy2);
		game.time.events.add(2500, launchEnemy1);
		game.time.events.add(4000, launchEnemy1);
		game.time.events.add(5000, launchEnemy4);	
		game.time.events.add(6000, launchEnemy4);
		game.time.events.add(6500, launchEnemy1);
		game.time.events.add(7000, launchEnemy4);
		game.time.events.add(7500, launchEnemy1);
		game.time.events.add(8000, launchEnemy4);
		game.time.events.add(9000, launchEnemy4);
		game.time.events.add(9500, launchEnemy1);
		game.time.events.add(10000, launchEnemy2);
		game.time.events.add(13000, launchEnemy2);
		game.time.events.add(15000, launchEnemy2);
		game.time.events.add(18000, launchEnemy2);
		game.time.events.add(20000, launchEnemy3);	
		game.time.events.add(21500, launchEnemy1);		
		game.time.events.add(25000, launchEnemy2);	
		game.time.events.add(26000, launchEnemy1);
		// 3 лвл оружия и жив
		//game.time.events.add(27000, chest(3));
		
	}
	
	function update() {
		if (player.alive){
			field.tilePosition.y += 0.1;    // "передвижение" фона при жизни игркока
		}			                        // "передвижение" фона
		
	    player.body.velocity.setTo(0, 0);	
		
		if (game.input.keyboard.addKey(Phaser.Keyboard.A).isDown){ 
			player.body.velocity.x = -200 - SpeedChar;
		}  
		if (game.input.keyboard.addKey(Phaser.Keyboard.D).isDown){
			player.body.velocity.x = 200 + SpeedChar;
		} 	
		if (game.input.keyboard.addKey(Phaser.Keyboard.W).isDown){
			player.body.velocity.y = -200 - SpeedChar;
		} 
		if (game.input.keyboard.addKey(Phaser.Keyboard.S).isDown){
			player.body.velocity.y = 200 + SpeedChar;
		} 
		
		if (player.x > game.width - 30){  // запрет на выход за границы экрана
			player.x = game.width - 30;
			player.body.acceleration.x = 0;
		}
		if (player.x < 30){
			player.x = 30;
			player.body.acceleration.x = 0;
		}
		if (player.y > game.height - 30){  
			player.y = game.height - 30;
			player.body.acceleration.y = 0;
		}
		if (player.y < 30){
			player.y = 30;
			player.body.acceleration.y = 0;
		}
		
		if (player.alive && game.input.activePointer.isDown){  // при нажатии пробела
			fireBullet();
    	}
		if (OP > 0 && player.alive && game.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR).isDown){  // при нажатии пробела
			player.kill();
    	}
		
		effect.x = player.x + 4;   // передвижение эффекта сзади коробля
		effect.y = player.y + 35;
	 	
		game.physics.arcade.overlap(Enemy2evilBullets, player, enemyHitsPlayer, null, this); // попадание в игрока		
		game.physics.arcade.overlap(Enemy1, brimstone, hitEnemy, null, this); // попадание в игрока лазером
		game.physics.arcade.overlap(Enemy2, brimstone, hitEnemy, null, this); 
		game.physics.arcade.overlap(Enemy3, brimstone, hitEnemy, null, this); 
		game.physics.arcade.overlap(Enemy4, brimstone, hitEnemy, null, this); 
		game.physics.arcade.overlap(Enemy1, bullets, hitEnemy, null, this);   // попадание во врага
		game.physics.arcade.overlap(Enemy2, bullets, hitEnemy, null, this);	
		game.physics.arcade.overlap(Enemy3, bullets, hitEnemy, null, this);	
		game.physics.arcade.overlap(Enemy4, bullets, hitEnemy, null, this);				
		game.physics.arcade.overlap(player, Enemy1, shipCollide, null, this); // столкновение
		game.physics.arcade.overlap(player, Enemy2, shipCollide, null, this);
		game.physics.arcade.overlap(player, Enemy3, shipCollide, null, this);
		game.physics.arcade.overlap(player, Enemy4, shipCollide, null, this);	
		game.physics.arcade.overlap(player, Bonus1, shipCollide, null, this);	
		game.physics.arcade.overlap(player, Bonus2, shipCollide, null, this);	
		game.physics.arcade.overlap(player, Bonus3, shipCollide, null, this);
		game.physics.arcade.overlap(player, Bonus4, shipCollide, null, this);	
		game.physics.arcade.overlap(player, Bonus5, shipCollide, null, this);
		game.physics.arcade.overlap(player, Bonus6, shipCollide, null, this);			
		if (!player.alive){            // когда игрок умирает
			game.time.events.remove(Enemy1LaunchTimer);
			game.time.events.remove(Enemy2LaunchTimer);
			game.time.events.remove(Enemy3LaunchTimer);
			game.time.events.remove(Enemy4LaunchTimer);
			field.tilePosition.y += 0; 
			effect.kill();
			gameOverText = game.add.text(game.world.centerX, game.world.centerY, 'GAME OVER!', { font: '84px Arial', fill: '#fff' });
			gameOverText.anchor.setTo(0.5, 0.5);
			button = game.add.button(game.world.centerX-175, game.world.centerY+50, 'button', function() {    
			window.open("http://localhost/laravel/shop/public/picture", "_blank");}, this);
			gameover.play;
		//	if ( music.volume > 0.1) {
		//		music.volume -= 0.1;
		//	}		
		}
	}
	
	function fireBullet() {                               // событие "Выстрел"
		switch (player.weaponLevel) {
        	case 1:
        	if (game.time.now > bulletTimer){
				var bullet = bullets.getFirstExists(false);
				if (bullet){
					var BulletSpacing = 300 - BulletSpacingChar;
					var bulletSpeed = 300 + BulletSpeedChar;
					power = 1 + PowerChar;
					bullet.reset(player.x + 21, player.y);
					bullet.angle = player.angle;
					bulletTimer = game.time.now + BulletSpacing;
					game.physics.arcade.velocityFromAngle(bullet.angle - 90, bulletSpeed, bullet.body.velocity); 	
					wpn1.play(); 
				}
			}
			break;
			
			case 2:
			if (game.time.now > bulletTimer) {
				for (var i = 0; i < 2; i++) {
					var bullet = bullets.getFirstExists(false);
					if (bullet) {
						power = 1 + PowerChar;
						var bulletSpacing = 300 - BulletSpacingChar;
						var bulletOffset = 20 * Math.sin(game.math.degToRad(player.angle));
						var bulletSpeed = 300 + BulletSpeedChar;
						var spreadAngle;
						bullet.reset(player.x + 21, player.y);						
						if (i === 0) spreadAngle = -10;
						if (i === 1) spreadAngle = 10;
						bullet.angle = player.angle + spreadAngle;
						bulletTimer = game.time.now + bulletSpacing;
						game.physics.arcade.velocityFromAngle(spreadAngle - 90, bulletSpeed, bullet.body.velocity);
						wpn1.play();
					}
				}
			}
			break;
			
			case 3:
			if (game.time.now > bulletTimer){
				var bullet = bullets.getFirstExists(false);
				if (bullet){
					var BulletSpacing = 1000 - BulletSpacingChar;
					var bulletSpeed = 300 + BulletSpeedChar;
					power = 5 + PowerChar;
					bullet.reset(player.x + 21, player.y);
					bullet.angle = player.angle;
					bulletTimer = game.time.now + BulletSpacing;
					game.physics.arcade.velocityFromAngle(bullet.angle - 90, 1000, bullet.body.velocity); 			
					wpn1.play();
				}
			}
			break;
			
			case 4:
			if (game.time.now > bulletTimer) {
				for (var i = 0; i < 4; i++) {
					var bullet = bullets.getFirstExists(false);
					if (bullet) {
						var bulletOffset = 20 * Math.sin(game.math.degToRad(player.angle));
						var BulletSpacing = 350 - BulletSpacingChar;
						var bulletSpeed = 300 + BulletSpeedChar;
						var spreadAngle;
						power = 1 + PowerChar;
						bullet.reset(player.x + 21, player.y);
						if (i === 0) spreadAngle = -10;
						if (i === 1) spreadAngle = 10;
						if (i === 2) spreadAngle = 45;
						if (i === 3) spreadAngle = -45;
						bullet.angle = player.angle + spreadAngle;
						bulletTimer = game.time.now + BulletSpacing;
						game.physics.arcade.velocityFromAngle(spreadAngle - 90, bulletSpeed, bullet.body.velocity);
						wpn1.play();
					}
				}
			}
			break;
			
			case 5: 
			{
				var bullet = brimstone.getFirstExists(false);
				if (bullet) {
					var BulletSpacing = 1;
					var bulletSpeed = 2000 + BulletSpeedChar;
					power = 0.2;
					bullet.reset(player.x + 8, player.y);
					bullet.angle = player.angle;
					game.physics.arcade.velocityFromAngle(bullet.angle - 90, bulletSpeed, bullet.body.velocity);
					wpn1.play(); 
				}
			}				
			break;
		}
	}
	
	function launchEnemy1() {                             // астероиды      
		var speedEnemy1 = 40 + DifficultySpeed;
		var point = 10;
		var hp = 5;
		var enemy = Enemy1.getFirstExists(false);
		if (enemy) {
			enemy.score = point;
			enemy.hp = hp;
			enemy.damageAmount = 30;
			enemy.reset(game.rnd.integerInRange(0, game.width), -20);
			enemy.body.velocity.x = game.rnd.integerInRange(-250, 250);
			enemy.body.velocity.y = speedEnemy1;
			enemy.body.drag.x = 100;  
			enemy.update = function(){	
				if (this.y > game.height + 200) {  // убийство за экраном
					this.kill();
				}
			}
		}
	}
	
	function launchEnemy2() {                             // корабли
		var startingX = game.rnd.integerInRange(100, game.width - 100);
		var verticalSpeed = 200 + DifficultySpeed;
		var spread = 60;
		var point = 25;
		var hp = 2;
		var frequency = 70;
		var verticalSpacing = 70;
		var numEnemiesInWave = 5;
		var timeBetweenWaves = 7000;  // 7000
		for (var i = 0; i < numEnemiesInWave; i++) {
			var enemy = Enemy2.getFirstExists(false);
			if (enemy) { 
				enemy.damageAmount = 25;
				enemy.hp = hp;
			    enemy.score = point;  // ОЧКИ ЗА ВРАГА
				enemy.startingX = player.x; 
				enemy.reset(game.width / 2, -verticalSpacing * i);
				enemy.body.velocity.y = verticalSpeed;
				var bulletSpeed = 500;                   // характеристики пуль второго врага
            	var firingDelay = 2000;
            	enemy.bullets = 10;
            	enemy.lastShot = 0;
				enemy.update = function(){	
					this.body.x = this.startingX + Math.sin((this.y) / frequency) * spread; //  Передвижение
					if (this.y > game.height + 200) {  // убийство за экраном
						this.kill();
					}
					enemyBullet = Enemy2evilBullets.getFirstExists(false);         // описание полета вражеской пули
					if (enemyBullet && this.alive && this.bullets 
					&& this.y > game.width / 8 && game.time.now > firingDelay + this.lastShot) {
						this.lastShot = game.time.now;
						this.bullets--;
						enemyBullet.reset(this.x, this.y + this.height / 2);
						enemyBullet.damageAmount = this.damageAmount;
						var angle = game.physics.arcade.moveToObject(enemyBullet, player, bulletSpeed);
						enemyBullet.angle = game.math.radToDeg(angle); 
					} 
				}
			}
		}
	}
	
	function launchEnemy3() {                             // самоубийца-копия    
		var speedEnemy3 = 100 + DifficultySpeed;
		var point = 50;
		var hp = 10;
		var enemy = Enemy3.getFirstExists(false);
		if (enemy) {
			enemy.score = point;
			enemy.damageAmount = 50;
			enemy.hp = hp;
			enemy.reset(400, -20);
			enemy.body.velocity.y = speedEnemy3;
			enemy.update = function(){	
				this.body.x = player.body.x + 20; 
				if (this.y > game.height + 200) {  
					this.kill();
				}
			}
		}
	}
	
	function launchEnemy4() {                             // лазерщик     
		var speedEnemy4 = 100 + DifficultySpeed;
		var point = 50;
		var enemyhp = 3;
		var left = 1;
		var enemy = Enemy4.getFirstExists(false);
		if (enemy) {
			enemy.score = point;
			enemy.damageAmount = 5;
			enemy.hp = enemyhp;
			enemy.reset(game.rnd.integerInRange(0, game.width), -20);
			enemy.body.velocity.y = speedEnemy4;
			var laser = lasers.getFirstExists(false);
			enemy.update = function(){
				if (left === 1){
					enemy.x -= 2;
				}
				else {
					enemy.x += 2;
				}
				if (enemy.x < 50){
					left = 0;
				}
				if (enemy.x > 700){
					left = 1;
				}
				
				if (this.alive && this.x > player.x - 10 && this.x < player.x + 10 && this.y < player.y) {
					if (laser) {
						laser.reset(this.body.x + 12, this.body.y + 350);
					}
					player.damage(this.damageAmount);
					hp.render();	
				}
				else {	
					laser.visible = false;
				}		
				if (this.y > game.height) {  // убийство за экраном
					this.kill();
				}	
				if (!this.alive) {
					laser.kill();
				}     				
			}
		} 
	}
	
	function launchBonus() {	
		var BonusType = game.rnd.integerInRange(0,5);
		if (BonusType === 0) {  // BulletSpeed
			var enemy = Bonus2.getFirstExists(false);
			enemy.damageAmount = -2;	
		}
		if (BonusType === 1) {   // SpeedChar
			var enemy = Bonus1.getFirstExists(false);
			enemy.damageAmount = -1;
		}		
		if (BonusType === 2) {   
			var enemy = Bonus3.getFirstExists(false);
			enemy.damageAmount = -3;
		}		
		if (BonusType === 3) {   
			var enemy = Bonus4.getFirstExists(false);
			enemy.damageAmount = -4;
		}	
		if (BonusType === 4) {  
			var enemy = Bonus5.getFirstExists(false);
			enemy.damageAmount = -5;
		}	
		if (BonusType === 5) {  
			var enemy = Bonus6.getFirstExists(false);
			enemy.damageAmount = -6;
		}			
		if (enemy) {
			enemy.reset(XBonus, YBonus);
			enemy.body.velocity.y = 100;
			enemy.body.x = XBonus;
			enemy.body.y = YBonus;
		} 
	}
	
	function chest(count) {	
		for (i=0;i<count;i++){
			var BonusType = game.rnd.integerInRange(0,5);
			if (BonusType === 0) {  // BulletSpeed
				var enemy = Bonus2.getFirstExists(false);
				enemy.damageAmount = -2;	
			}
			if (BonusType === 1) {   // SpeedChar
				var enemy = Bonus1.getFirstExists(false);
				enemy.damageAmount = -1;
			}		
			if (BonusType === 2) {   
				var enemy = Bonus3.getFirstExists(false);
				enemy.damageAmount = -3;
			}		
			if (BonusType === 3) {   
				var enemy = Bonus4.getFirstExists(false);
				enemy.damageAmount = -4;
			}	
			if (BonusType === 4) {  
				var enemy = Bonus5.getFirstExists(false);
				enemy.damageAmount = -5;
			}	
			if (BonusType === 5) {  
				var enemy = Bonus6.getFirstExists(false);
				enemy.damageAmount = -6;
			}			
			if (enemy) {
				enemy.reset(400, -10 + i * 30);
				enemy.body.velocity.y = 100;			
			}
		} 
	}
	
 	function shipCollide(player, enemy) {                 // событие "Столкновение"
		if (enemy.damageAmount === -1){
			SpeedChar = SpeedChar + 15;
			enemy.kill(); 
			BonusType = 0;
			return;
		}		
		if (enemy.damageAmount === -2){
			BulletSpeedChar = BulletSpeedChar + 15;
			enemy.kill(); 
			BonusType = 0;
			return;
		}		
		if (enemy.damageAmount === -3){
			BulletSpacingChar = BulletSpacingChar + 15;
			enemy.kill(); 
			BonusType = 0;
			return;
		}	
		if (enemy.damageAmount === -4){
			PowerChar = PowerChar + 0,1;
			enemy.kill(); 
			BonusType = 0;
			return;
		}	
		if (enemy.damageAmount === -5){
			OP += 1;
			enemy.kill(); 
			OPText.render();
			BonusType = 0;
			return;
		}	
		if (enemy.damageAmount === -6){
			player.damage(-25);
			enemy.kill(); 
			hp.render();
			BonusType = 0;
			return;
		}	
		var explosion = explosions.getFirstExists(false);
		explosion.reset(enemy.body.x + enemy.body.halfWidth, enemy.body.y + enemy.body.halfHeight);
		explosion.body.velocity.y = enemy.body.velocity.y;
		explosion.alpha = 0.7;
		explosion.play('explosion', 30, false, true);	
		player.damage(enemy.damageAmount);
		hp.render();
		enemy.kill(); 	
		if (! player.alive){  
			gameover.play();
		}
	}
	
	function hitEnemy(enemy, bullet) {                    // попадание по врагу
		var explosion = explosions.getFirstExists(false);
		var weaponLevel = weaponLevel;
		if (player.weaponLevel === 5) {
			enemy.hp = enemy.hp - power;
		}
		else
		{
			enemy.hp = enemy.hp - power;
		}
		if (enemy.hp <= 0) {
			var Random;
			XBonus = enemy.body.x;
			YBonus = enemy.body.y;
			explosion.reset(bullet.body.x + bullet.body.halfWidth, bullet.body.y + bullet.body.halfHeight);
			explosion.body.velocity.y = enemy.body.velocity.y;
			explosion.alpha = 0.7;
			explosion.play('explosion', 30, false, true);						
			score += enemy.score;	
			enemy.kill();						
			Evil += 1;
			enemyCount.render();
			Random = game.rnd.integerInRange(0, 9);	// шанс выпадения бонуса
			if (Random === 1){  
				game.time.events.add(1, launchBonus);
			}  
		}
		if (!player.weaponLevel === 3){
			bullet.kill();
		}
		if (player.weaponLevel === 5) 
		{
			scoreText.render();  
			return;
		}
	    if (score > 100 && score < 250)
		{
			player.weaponLevel = 2;
		}
		if (score > 250 && score < 500)
		{
			player.weaponLevel = 3;
		} 
		if (score > 500)
		{
			player.weaponLevel = 4;
		}  
		scoreText.render();  
	}
	
	function enemyHitsPlayer(player, bullet) {           // попадание по игроку вражеской пулей
		var explosion = explosions.getFirstExists(false);
		explosion.reset(player.body.x + player.body.halfWidth, player.body.y + player.body.halfHeight);
		explosion.alpha = 0.7;
		explosion.play('explosion', 30, false, true);
		bullet.kill();
		player.damage(bullet.damageAmount);
		hp.render()
	}   
	
	function render() {
	}
	}
    </script>

    </body>
</html>